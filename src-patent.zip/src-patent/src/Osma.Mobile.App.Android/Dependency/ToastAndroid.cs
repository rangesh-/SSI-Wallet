﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Osma.Mobile.App.Droid.Dependency;
using Osma.Mobile.App.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin.Forms;

[assembly: Dependency(typeof(ToastAndroid))]
namespace Osma.Mobile.App.Droid.Dependency
{
    public class ToastAndroid : ToastMessage
    {
        public void ShowAlert(string message)
        {
            Android.Widget.Toast.MakeText(Android.App.Application.Context, message, ToastLength.Long).Show();
        }
    }
}