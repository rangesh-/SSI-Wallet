using System;

namespace Osma.Mobile.App
{
    public class AppConstant
    {
        public const string IosAnalyticsKey = "injected-via-ci";

        public const string AndroidAnalyticsKey = "injected-via-ci";

        internal const string LocalWalletProvisioned = "aries.settings.walletprovisioned";
        public static bool fromFiosApp = false;

        public static bool SwitchVal = false;

        public static long TimeValue = 0;
    }
}