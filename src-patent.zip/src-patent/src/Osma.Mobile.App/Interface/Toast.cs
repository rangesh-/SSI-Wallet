﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Osma.Mobile.App.Interface
{
    public interface ToastMessage
    {
        void ShowAlert(string message);
    }
}
