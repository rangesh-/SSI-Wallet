﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace Osma.Mobile.App
{
    public class TimeBehavior : Behavior<TimePicker>
    {
        /// <summary>
        /// The command property.
        /// </summary>
        public static readonly BindableProperty CommandProperty = BindableProperty.Create(nameof(Command), typeof(ICommand), typeof(TimeBehavior), null);

        /// <summary>
        /// Gets or sets the command.
        /// </summary>
        /// <value>The command.</value>
        public ICommand Command
        {
            get { return (ICommand)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        /// <summary>
        /// Gets the bindable.
        /// </summary>
        /// <value>The bindable.</value>
        public TimePicker Bindable { get; private set; }

        /// <summary>
        /// On attached to.
        /// </summary>
        /// <param name="bindable">The bindable component.</param>
        protected override void OnAttachedTo(TimePicker bindable)
        {
            base.OnAttachedTo(bindable);
            Bindable = bindable;
            Bindable.BindingContextChanged += OnBindingContextChanged;
            Bindable.PropertyChanged += Bindable_PropertyChanged;
        }

        private void Bindable_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            Command?.Execute(Bindable.Time);
        }

        /// <summary>
        /// Ons the binding context changed.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The event.</param>
        private void OnBindingContextChanged(object sender, EventArgs e)
        {
            OnBindingContextChanged();
            BindingContext = Bindable.BindingContext;
        }

        /// <summary>
        /// Ons the switch toggled.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The event.</param>
        private void OnSwitchToggled(object sender, ToggledEventArgs e)
        {
            Command?.Execute(e.Value);
        }

        /// <summary>
        /// On detaching from.
        /// </summary>
        /// <param name="bindable">The bindable component.</param>
        protected override void OnDetachingFrom(TimePicker bindable)
        {
            base.OnDetachingFrom(bindable);
            Bindable.BindingContextChanged -= OnBindingContextChanged;
            Bindable.PropertyChanged -= Bindable_PropertyChanged;
            Bindable = null;
        }
    }
}
