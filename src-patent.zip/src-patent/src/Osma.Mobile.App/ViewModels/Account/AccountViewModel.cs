﻿using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using Osma.Mobile.App.Services;
using Osma.Mobile.App.Services.Interfaces;
using ReactiveUI;
using Xamarin.Forms;
using Xamarin.Essentials;
using Osma.Mobile.App.Views.Legal;
using System;

namespace Osma.Mobile.App.ViewModels.Account
{
    public class AccountViewModel : ABaseViewModel
    {
        public AccountViewModel(
            IUserDialogs userDialogs,
            INavigationService navigationService
        ) : base(
            "Account",
            userDialogs,
            navigationService
        )
        {
            AppConstant.SwitchVal = false;
            AppConstant.TimeValue = 0;

            MySwitchCommand = new Command<bool>(async (value) =>
            {
                await ExecuteSwitchCommand(value);
            });

            MyTimePickerCommand = new Command<TimeSpan>(async (value) =>
            {
                await ExecutePickerCommand(value);
            });
        }

        private async Task ExecutePickerCommand(TimeSpan value)
        {
            var _triggerTime = DateTime.Now + value;
            long unixTime = ((DateTimeOffset)_triggerTime).ToUnixTimeSeconds();
            TimeProperty = unixTime;
            AppConstant.TimeValue = TimeProperty;
        }

        private async Task ExecuteSwitchCommand(bool value)
        {
            SwitchValue = value.ToString();
            AppConstant.SwitchVal = value;
            EnabledProperty = true;
        }

        //public async Task NavigateToBackup()
        //{
        //    await DialogService.AlertAsync("Navigate to Backup");
        //}

        //public async Task NavigateToAuthentication()
        //{
        //    await DialogService.AlertAsync("Navigate to authentication");
        //}

        //public async Task NavigateToLegalPage()
        //{
        //    var legalPage = new LegalPage();
        //    await NavigationService.NavigateToAsync(legalPage, NavigationType.Modal);
        //}

        //public async Task NavigateToDebug()
        //{
        //    await DialogService.AlertAsync("Navigate to debug page");
        //}

        #region Bindable Command

        //public ICommand NavigateToBackupCommand => new Command(async () => await NavigateToBackup());

        //public ICommand NavigateToAuthenticationCommand => new Command(async () => await NavigateToAuthentication());

        //public ICommand NavigateToLegalPageCommand => new Command(async () => await NavigateToLegalPage());

        //public ICommand NavigateToDebugCommand => new Command(async () => await NavigateToDebug());

        #endregion

        #region Bindable Properties

        private string _fullName;
        public string FullName
        {
            get => _fullName;
            set => this.RaiseAndSetIfChanged(ref _fullName, value);
        }

        private string _avatarUrl;
        public string AvatarUrl
        {
            get => _avatarUrl;
            set => this.RaiseAndSetIfChanged(ref _avatarUrl, value);
        }

        private bool _showDebug;
        public bool ShowDebug
        {
            get => _showDebug;
            set => this.RaiseAndSetIfChanged(ref _showDebug, value);
        }

        private string _appVersion;
        public string AppVersion
        {
            get => _appVersion;
            set => this.RaiseAndSetIfChanged(ref _appVersion, value);
        }

        private string _buildVersion;
        public string BuildVersion
        {
            get => _buildVersion;
            set => this.RaiseAndSetIfChanged(ref _buildVersion, value);
        }


        private long _selectedTime;
        public long TimeProperty
        {
            get => _selectedTime;
            set => this.RaiseAndSetIfChanged(ref _selectedTime, value);
        }

        private bool _enabledProperty;
        public bool EnabledProperty
        {
            get => _enabledProperty;
            set => this.RaiseAndSetIfChanged(ref _enabledProperty, value);
        }

        private string _switchValue;
        public string SwitchValue
        {
            get { return _switchValue; }
            set { this.RaiseAndSetIfChanged(ref _switchValue, value); }
        }

        public ICommand MySwitchCommand { get; set; }
        public ICommand MyTimePickerCommand { get; set; }
        #endregion
    }
}
