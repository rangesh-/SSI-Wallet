﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reactive.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using Hyperledger.Aries.Agents;
using Hyperledger.Aries.Extensions;
using Hyperledger.Aries.Features.DidExchange;
using Osma.Mobile.App.Services.Interfaces;
using ReactiveUI;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration;
using ZXing.Net.Mobile.Forms;

namespace Osma.Mobile.App.ViewModels.CreateInvitation
{
    public class CreateInvitationViewModel : ABaseViewModel
    {
        private readonly IAgentProvider _agentContextProvider;
        private readonly IConnectionService _connectionService;
        readonly HttpClient client;
        readonly HttpClientHandler handler = new HttpClientHandler();
        readonly CookieContainer cookies = new CookieContainer();

        public CreateInvitationViewModel(
            IUserDialogs userDialogs,
            INavigationService navigationService,
            IAgentProvider agentContextProvider,
            IConnectionService defaultConnectionService
            ) : base(
                "CreateInvitation",
                userDialogs,
                navigationService
           )
        {
            _agentContextProvider = agentContextProvider;
            _connectionService = defaultConnectionService;
            handler.CookieContainer = cookies;
            client = new HttpClient(handler);
        }

        public override async Task InitializeAsync(object navigationData)
        {
            await base.InitializeAsync(navigationData);
        }

        private async Task CreateInvitation()
        {
            if (AppConstant.SwitchVal)
            {
                var result = await UserDialogs.Instance.PromptAsync(null, "Enter Your Friendly Name", "OK", "CANCEL", "", InputType.Default, null);
                {
                    if ((result.Text != null) && (result.Ok ==true))
                    {
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            try
                            {
                                var context = await _agentContextProvider.GetContextAsync();
                                var (invitation, _) = await _connectionService.CreateInvitationAsync(context, new InviteConfiguration
                                {
                                    TheirAlias = new ConnectionAlias { Name = "Invitation" }
                                });

                                var id= System.Guid.NewGuid().ToString();
                                var time = AppConstant.TimeValue;
                                string barcodeValue = invitation.ServiceEndpoint + "?d_m=" + Uri.EscapeDataString(invitation.ToByteArray().ToBase64String());
                                
                              //  string url = "https://localhost:44322/shortner/getshortner?deviceid=2163aerq12&&orgurl=" + QrCodeValue + "&&validaitytimestamp=" + time + "&&friendlyurl="+result.Text;
                                using (var client = new HttpClient())
                                {
                                    client.BaseAddress = new Uri("http://192.168.0.7:53678/");
                                    client.DefaultRequestHeaders.Accept.Clear();
                                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                                    //GET Method  
                                    HttpResponseMessage response = await client.GetAsync("/shortner/getshortner?deviceid=2163aerq12&&orgurl=" + barcodeValue + "&&validaitytimestamp=" + time + "&&friendlyurl=" + result.Text);
                                    if (response.IsSuccessStatusCode)
                                    {
                                        var res1 = await response.Content.ReadAsStringAsync();
                                        QrCodeValue = res1;
                                    }
                                    else
                                    {
                                        QrCodeValue = barcodeValue;
                                    }
                                }
                                
                            }
                            catch (Exception ex)
                            {
                                DialogService.Alert(ex.Message);
                            }
                        });
                    }
                }
            }
            else
            {
                UserDialogs.Instance.Alert("Please enable Timer in Settings", "Warning", "OK");
            }
        }

        public async Task<T> GetDataAsync<T>(string getUrl)
        {
            var uri = new Uri(string.Format(getUrl, string.Empty));
            T items;
            try
            {
                HttpResponseMessage response = null;
                response = await client.GetAsync(uri);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    items = JsonSerializer.Deserialize<T>(content);
                    return items;
                }
                else
                {
                    UserDialogs.Instance.Alert("InvalidUrl", null, null);
                }
            }
            catch (Exception ex)
            {

            }
            return default(T);
        }


        public async Task<T> PostDataAsync<T>(string url)
        {
            try
            {
                var uri = new Uri(string.Format(url, string.Empty));

                HttpResponseMessage response = null;
                response = await client.PostAsync(uri,null);
                if (response.IsSuccessStatusCode)
                {
                    var Postcontent = await response.Content.ReadAsStringAsync();
                    var items = JsonSerializer.Deserialize<T>(Postcontent);
                    return items;
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.Alert("InvalidUrl", null, null);
            }
            return default(T);
        }
        private ZXingBarcodeImageView QRCodeGenerator(string barcodeValue)
        {
            var barcode = new ZXingBarcodeImageView
            {
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand,
                AutomationId = "zxingBarcodeImageView",
            };

            barcode.BarcodeFormat = ZXing.BarcodeFormat.QR_CODE;
            barcode.BarcodeOptions.Width = 300;
            barcode.BarcodeOptions.Height = 300;
            barcode.BarcodeOptions.Margin = 10;
            barcode.BarcodeValue = barcodeValue;

            return barcode;

        }

        #region Bindable Command

        public ICommand CreateInvitationCommand => new Command(async () => await CreateInvitation());

        #endregion

        #region Bindable Properties

        private string _qrCodeValue;

        public string QrCodeValue
        {
            get => _qrCodeValue;
            set => this.RaiseAndSetIfChanged(ref _qrCodeValue, value);
        }

        #endregion
    }
}
