﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Osma.Mobile.App.ViewModels
{
    public class ResponseModel
    {
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        public class Presentation
        {
        }

        public class PresentationProposalDict
        {
        }

        public class PresentationRequest
        {
        }

        public class PresentationRequestDict
        {
        }

        public class Root
        {
            public bool auto_present { get; set; }
            public string connection_id { get; set; }
            public string created_at { get; set; }
            public string error_msg { get; set; }
            public string initiator { get; set; }
            public Presentation presentation { get; set; }
            public string presentation_exchange_id { get; set; }
            public PresentationProposalDict presentation_proposal_dict { get; set; }
            public PresentationRequest presentation_request { get; set; }
            public PresentationRequestDict presentation_request_dict { get; set; }
            public string role { get; set; }
            public string state { get; set; }
            public string thread_id { get; set; }
            public bool trace { get; set; }
            public string updated_at { get; set; }
            public string verified { get; set; }
        }


    }
}
