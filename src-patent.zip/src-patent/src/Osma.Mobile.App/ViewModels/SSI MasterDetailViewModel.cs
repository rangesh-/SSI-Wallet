﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using Autofac;
using Hyperledger.Aries.Agents;
using Hyperledger.Aries.Contracts;
using Hyperledger.Aries.Features.DidExchange;
using Hyperledger.Aries.Features.IssueCredential;
using Osma.Mobile.App.Events;
using Osma.Mobile.App.Extensions;
using Osma.Mobile.App.Services;
using Osma.Mobile.App.Services.Interfaces;
using Osma.Mobile.App.Utilities;
using Osma.Mobile.App.Views;
using ReactiveUI;
using Xamarin.Forms;

namespace Osma.Mobile.App.ViewModels
{
    public class SSI_MasterDetailViewModel 
    {
        //private readonly ICredentialService _credentialService;
        //private readonly IAgentProvider _agentContextProvider;
        //private readonly ILifetimeScope _scope;
        //private readonly IEventAggregator _eventAggregator;
        //private readonly IConnectionService _connectionService;
        public ObservableCollection<SSIMasterDetailPageMasterMenuItem> MenuItems { get; set; }
        public SSI_MasterDetailViewModel()
            //IUserDialogs userDialogs,
            //INavigationService navigationService,
            //ICredentialService credentialService,
            //IConnectionService connectionService,
            //IAgentProvider agentContextProvider,
            //IEventAggregator eventAggregator,
            //ILifetimeScope scope
            //) : base("Credentials", userDialogs, navigationService)
        {
            //_connectionService = connectionService;
            //_credentialService = credentialService;
            //_agentContextProvider = agentContextProvider;
            //this._eventAggregator = eventAggregator;
            //_scope = scope;

            //this.WhenAnyValue(x => x.SearchTerm)
            //    .Throttle(TimeSpan.FromMilliseconds(200))
            //    .InvokeCommand(RefreshCommand);

            MenuItems = new ObservableCollection<SSIMasterDetailPageMasterMenuItem>(new[]
                {
                    new SSIMasterDetailPageMasterMenuItem { Id = 0, Title = "Page 1" },
                    new SSIMasterDetailPageMasterMenuItem { Id = 1, Title = "Page 2" },
                    new SSIMasterDetailPageMasterMenuItem { Id = 2, Title = "Page 3" },
                    new SSIMasterDetailPageMasterMenuItem { Id = 3, Title = "Page 4" },
                    new SSIMasterDetailPageMasterMenuItem { Id = 4, Title = "Page 5" },
                });
        }

        //public override async Task InitializeAsync(object navigationData)
        //{
        //    //await RefreshCredentials();
        //    //_eventAggregator.GetEventByType<ApplicationEvent>()
        //    //               .Where(_ => _.Type == ApplicationEventType.CredentialsUpdated)
        //    //               .Subscribe(async _ => await RefreshCredentials());
        //    await base.InitializeAsync(navigationData);
        //}

        #region INotifyPropertyChanged Implementation
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            if (PropertyChanged == null)
                return;

            PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
