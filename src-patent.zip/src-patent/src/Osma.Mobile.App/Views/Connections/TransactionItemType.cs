﻿namespace Osma.Mobile.App.Views.Connections
{
    public enum TransactionItemType
    {
        None,
        Action = 1,
        MultiAction = 2,
        Status = 3
    }
}
