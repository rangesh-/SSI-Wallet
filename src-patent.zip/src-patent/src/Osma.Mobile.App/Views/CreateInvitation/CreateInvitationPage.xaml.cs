﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Osma.Mobile.App.Views.CreateInvitation
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CreateInvitationPage : ContentPage
    {
        public CreateInvitationPage()
        {
            InitializeComponent();
        }
    }
}
