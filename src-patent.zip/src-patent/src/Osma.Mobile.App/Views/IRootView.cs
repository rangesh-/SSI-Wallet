﻿namespace Osma.Mobile.App.Views
{
    //TODO this is code smell, should get rid of it
    public interface IRootView { }
}
