﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Osma.Mobile.App.Views.Legal
{
    public partial class LegalPage : ContentPage
    {
        public LegalPage()
        {
            InitializeComponent();
        }
    }
}
