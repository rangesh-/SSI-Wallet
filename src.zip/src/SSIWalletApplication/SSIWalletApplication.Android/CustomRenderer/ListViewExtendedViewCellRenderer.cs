﻿using Android.App;
using Android.Content;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SSIWalletApplication.CustomRenderer;
using SSIWalletApplication.Droid.CustomRenderer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(ListViewExtendedViewCell), typeof(ListViewExtendedViewCellRenderer))]
namespace SSIWalletApplication.Droid.CustomRenderer
{
    public class ListViewExtendedViewCellRenderer : ViewCellRenderer
    {
        private Android.Views.View _cellCore;
        private Drawable _unselectedBackground;
        private bool _selected;

        protected override Android.Views.View GetCellCore(Cell item,
                                                         Android.Views.View convertView,
                                                         ViewGroup parent,
                                                         Context context)
        {
            try
            {

                _cellCore = base.GetCellCore(item, convertView, parent, context);

                _selected = false;
                _unselectedBackground = _cellCore.Background;

                return _cellCore;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }
        protected override void OnCellPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            try
            {
                base.OnCellPropertyChanged(sender, e);

                if (e.PropertyName == "IsSelected")
                {
                    _selected = !_selected;
                    var extendedViewCell = sender as ListViewExtendedViewCell;
                    _cellCore.SetBackgroundColor(extendedViewCell.SelectedBackgroundColor.ToAndroid());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}