﻿using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace SSIWalletApplication.Droid
{
    [Activity(Label = "SSI", Icon = "@mipmap/icon", Theme = "@style/SplashTheme", NoHistory = true, LaunchMode = LaunchMode.SingleTop, ScreenOrientation = ScreenOrientation.Portrait,
        MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize)]
    public class SplashActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            //SetContentView(Resource.Layout.splashscreen);
            ThreadPool.QueueUserWorkItem(o => LoadActivity());
        }

        private void LoadActivity()
        {
            Thread.Sleep(1000); // Simulate a long pause
            RunOnUiThread(() => StartActivity(typeof(MainActivity)));
        }

        //// Simulates background work that happens behind the splash screen
        //async void SimulateStartup()
        //{
        //    await Task.Delay(8000); // AND AT HERE YOU CAN DECREASE YOUR SPLASH SCREEN TIME.
        //    StartActivity(new Intent(Application.Context, typeof(MainActivity)));
        //}
    }
}