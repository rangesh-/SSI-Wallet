﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SSIWalletApplication.Constants
{
    public class AppConstant
    {
        public const string IosAnalyticsKey = "injected-via-ci";

        public const string AndroidAnalyticsKey = "injected-via-ci";

        internal const string LocalWalletProvisioned = "aries.settings.walletprovisioned";

        public const string IsHomePageEnabled = "no";
        public const string IsLocalWallet = "yes";
        public const string ScanValue = "value";
    }
}
