﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace SSIWalletApplication.CustomRenderer
{
    public class CustomEntry :Entry
    {
    }
}
