﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace SSIWalletApplication.CustomRenderer
{
    public class ListViewExtendedViewCell : ViewCell
    {
        public static readonly BindableProperty SelectedBackgroundColorProperty =
            BindableProperty.Create("SelectedBackgroundColor",
                                    typeof(Color),
                                    typeof(ListViewExtendedViewCell),
                                    Color.Default);

        /// <summary>
        /// Getter & Setter - SelectedBackgroundColorProperty
        /// </summary>
        public Color SelectedBackgroundColor
        {
            get { return (Color)GetValue(SelectedBackgroundColorProperty); }
            set { SetValue(SelectedBackgroundColorProperty, value); }
        }
    }
}

