﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SSIWalletApplication.Interface
{
    //TODO this is code smell, should get rid of it
    public interface IRootView { }
}
