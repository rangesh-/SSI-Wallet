﻿using Acr.UserDialogs;
using Autofac;
using Hyperledger.Aries.Agents;
using Hyperledger.Aries.Contracts;
using Hyperledger.Aries.Features.DidExchange;
using ReactiveUI;
using SSIWalletApplication.Constants;
using SSIWalletApplication.Extensions;
using SSIWalletApplication.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace SSIWalletApplication.ViewModels
{
    #region ConnectionsViewModel
    public class ConnectionsViewModel : ABaseViewModel
    {
        private string _scanValue;
        private readonly IConnectionService _connectionService;
        private readonly IAgentProvider _agentContextProvider;
        private readonly IEventAggregator _eventAggregator;
        private readonly ILifetimeScope _scope;

        public ConnectionsViewModel(IUserDialogs userDialogs,
                                    INavigationService navigationService,
                                    IConnectionService connectionService,
                                    IAgentProvider agentContextProvider,
                                    IEventAggregator eventAggregator,
                                    ILifetimeScope scope
                                    ) :
                                    base("Connections", userDialogs, navigationService)
        {
            _connectionService = connectionService;
            _agentContextProvider = agentContextProvider;
            _eventAggregator = eventAggregator;
            _scope = scope;
            PopUpViewVisibility = true;
            _scanValue = Preferences.Get(AppConstant.ScanValue,"");

            RefreshConnections();
        }

        public override async Task InitializeAsync(object navigationData)
        {
            await RefreshConnections();

            _eventAggregator.GetEventByType<ApplicationEvent>()
                            .Where(_ => _.Type == ApplicationEventType.ConnectionsUpdated)
                            .Subscribe(async _ => await RefreshConnections());

            await base.InitializeAsync(navigationData);
        }

        #endregion

        #region Methods
        public async Task RefreshConnections()
        {
            RefreshingConnections = true;

            if (_scanValue != null && _scanValue != "")
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    try
                    {
                        await Application.Current.MainPage.DisplayAlert("Confirmation", _scanValue + "was successfully added to your connections", "OK");
                    }
                    catch (Exception ex)
                    {

                    }
                });
                _scanValue = null;
            }

            var context = await _agentContextProvider.GetContextAsync();
            var records = await _connectionService.ListAsync(context);

            IList<ConnectionViewModel> connectionVms = new List<ConnectionViewModel>();
            foreach (var record in records)
            {
                var connection = _scope.Resolve<ConnectionViewModel>(new NamedParameter("record", record));
                if (connection.ConnectionName == null)
                {

                }
                else
                    connectionVms.Add(connection);
            }

            //TODO need to compare with the currently displayed connections rather than disposing all of them
            CollectionItems.Clear();
            CollectionItems.InsertRange(connectionVms);
            HasConnections = connectionVms.Any();

            RefreshingConnections = false;
        }

        private async Task SettingTappedMethod()
        {
            PopUpViewVisibility = true;
        }

        private async Task CrossImageTappedMethod()
        {
            PopUpViewVisibility = false;
        }

        private async Task SaveMethod()
        {
            PopUpViewVisibility = false;
        }

        public async Task SelectConnection(ConnectionViewModel connection) => await NavigationService.NavigateToAsync(connection);
        #endregion

        #region Bindable Command
        public ICommand RefreshCommand => new Command(async () => await RefreshConnections());
        public ICommand SettingTappedCommand => new Command(async () => await SettingTappedMethod());
        public ICommand CrossImageTapped => new Command(async () => await CrossImageTappedMethod());
        public ICommand SaveCommand => new Command(async () => await SaveMethod());

        public ICommand SelectConnectionCommand => new Command<ConnectionViewModel>(async (connection) =>
        {
            if (connection != null)
                await SelectConnection(connection);
        });
        #endregion

        #region Bindable Properties
        private RangeEnabledObservableCollection<ConnectionViewModel> _collectionItems = new RangeEnabledObservableCollection<ConnectionViewModel>();
        public RangeEnabledObservableCollection<ConnectionViewModel> CollectionItems
        {
            get => _collectionItems;
            set => this.RaiseAndSetIfChanged(ref _collectionItems, value);
        }

        private bool _hasConnections;
        public bool HasConnections
        {
            get => _hasConnections;
            set => this.RaiseAndSetIfChanged(ref _hasConnections, value);
        }

        private bool _refreshingConnections;
        public bool RefreshingConnections
        {
            get => _refreshingConnections;
            set => this.RaiseAndSetIfChanged(ref _refreshingConnections, value);
        }

        private bool _popUpViewVisibility;
        public bool PopUpViewVisibility
        {
            get => _popUpViewVisibility;
            set => this.RaiseAndSetIfChanged(ref _popUpViewVisibility, value);
        }

    }
    #endregion
}
