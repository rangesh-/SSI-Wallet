﻿using Acr.UserDialogs;
using ReactiveUI;
using SSIWalletApplication.Constants;
using SSIWalletApplication.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace SSIWalletApplication.ViewModels
{
        #region HomePage
    public class HomePageViewModel : ABaseViewModel, IRootView
    {
        public ContentView contentView;
        public HomePageViewModel(
        IUserDialogs userDialogs,
            INavigationService navigationService,
            ConnectionsViewModel connectionViewModel,
            CredentialsViewModel credentialViewModel,
            ScanViewModel scanViewModel,
            //NotificationViewModel notificationViewModel,
            ProofRequestsViewModel proofViewModel)
             : base(nameof(HomePageViewModel), userDialogs, navigationService)
        {
            Connections = connectionViewModel;
            Credentials = credentialViewModel;
            ScanResult = scanViewModel;
            //Notification = notificationViewModel;
            ProofRequests = proofViewModel;


            if (Preferences.Get(AppConstant.IsHomePageEnabled, false))
            {
                HomeLayoutVisibility = true;
            }
            else
            {
                HomeLayoutVisibility = false;
                Preferences.Set(AppConstant.IsHomePageEnabled, true);
            }

            CredentialTapMethod();
        }

        public override async Task InitializeAsync(object navigationData)
        {
            await Connections.InitializeAsync(null);
            await Credentials.InitializeAsync(null);
            await ScanResult.InitializeAsync(null);
            await ProofRequests.InitializeAsync(null);
            await base.InitializeAsync(navigationData);
        }
        #endregion

        #region Methods
        private async Task CredentialTapMethod()
        {
           // ViewModel = Credentials;
            NavigationService.CreateAndBindView<CredentialsViewModel>();
            CredentialTextColor = Color.Red;
            ScanTextColor = Color.White;
            ConnectionTextColor = Color.White;
            ProofTextColor = Color.White;
        }
        private async Task ScanTapMethod()
        {
            ViewModel = ScanResult;
            NavigationService.CreateAndBindView<ScanViewModel>();
            CredentialTextColor = Color.White;
            ScanTextColor = Color.Red;
            ConnectionTextColor = Color.White;
            ProofTextColor = Color.White;
        }
        private async Task ConnectionTapMethod()
        {
            ViewModel = Connections;
            NavigationService.CreateAndBindView<ConnectionsViewModel>();
            CredentialTextColor = Color.White;
            ScanTextColor = Color.White;
            ConnectionTextColor = Color.Red;
            ProofTextColor = Color.White;
        }
        private async Task ProofTapMethod()
        {
            ViewModel = ProofRequests;
            NavigationService.CreateAndBindView<ProofRequestsViewModel>();
            CredentialTextColor = Color.White;
            ScanTextColor = Color.White;
            ConnectionTextColor = Color.White;
            ProofTextColor = Color.Red;
        }
        //private async Task NotificationMethod()
        //{
        //    //ContentViews.BindingContext = Notification;
        //    CredentialTextColor = Color.White;
        //    ScanTextColor = Color.White;
        //    ConnectionTextColor = Color.White;
        //    ProofTextColor = Color.White;
        //}

        private async Task GettingStartedMethod()
        {
            HomeLayoutVisibility = true;
        }
        #endregion

        #region Bindable Commands
        public ICommand CredentialTapCommand => new Command(async () => await CredentialTapMethod());
        public ICommand ScanTapCommand => new Command(async () => await ScanTapMethod());
        public ICommand ConnectionTapCommand => new Command(async () => await ConnectionTapMethod());
        public ICommand ProofTapCommand => new Command(async () => await ProofTapMethod());
        //public ICommand NotificationCommand => new Command(async () => await NotificationMethod());
        public ICommand GetStartCommand => new Command(async () => await GettingStartedMethod());


        #endregion

        #region Bindable Properties

        private ConnectionsViewModel _connections;
        public ConnectionsViewModel Connections
        {
            get => _connections;
            set => this.RaiseAndSetIfChanged(ref _connections, value);
        }

        private CredentialsViewModel _credentials;
        public CredentialsViewModel Credentials
        {
            get => _credentials;
            set => this.RaiseAndSetIfChanged(ref _credentials, value);
        }

        private ProofRequestsViewModel _proofRequests;
        public ProofRequestsViewModel ProofRequests
        {
            get => _proofRequests;
            set => this.RaiseAndSetIfChanged(ref _proofRequests, value);
        }

        private ScanViewModel _scanResult;
        public ScanViewModel ScanResult
        {
            get => _scanResult;
            set => this.RaiseAndSetIfChanged(ref _scanResult, value);
        }

        //private NotificationViewModel _notification;
        //public NotificationViewModel Notification
        //{
        //    get => _notification;
        //    set => this.RaiseAndSetIfChanged(ref _notification, value);
        //}

        private ContentView _contentView;
        public ContentView ContentViews
        {
            get => _contentView;
            set => this.RaiseAndSetIfChanged(ref _contentView, value);
        }

        private IABaseViewModel _viewModel;
        public IABaseViewModel ViewModel
        {
            get => _viewModel;
            set => this.RaiseAndSetIfChanged(ref _viewModel, value);
        }

        private bool _homeVisibility;
        public bool HomeLayoutVisibility
        {
            get => _homeVisibility;
            set => this.RaiseAndSetIfChanged(ref _homeVisibility, value);
        }

        private Color _credentialTextColor;
        public Color CredentialTextColor
        {
            get => _credentialTextColor;
            set => this.RaiseAndSetIfChanged(ref _credentialTextColor, value);
        }

        private Color _scanTextColor;
        public Color ScanTextColor
        {
            get => _scanTextColor;
            set => this.RaiseAndSetIfChanged(ref _scanTextColor, value);
        }

        private Color _connectionTextColor;
        public Color ConnectionTextColor
        {
            get => _connectionTextColor;
            set => this.RaiseAndSetIfChanged(ref _connectionTextColor, value);
        }

        private Color _proofTextColor;
        public Color ProofTextColor
        {
            get => _proofTextColor;
            set => this.RaiseAndSetIfChanged(ref _proofTextColor, value);
        }
    }

    #endregion
}
