﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SSIWalletApplication.ViewModels
{
    class NotificationViewModel
    {
    }
}
