﻿using Acr.UserDialogs;
using Hyperledger.Aries.Agents;
using Hyperledger.Aries.Agents.Edge;
using SSIWalletApplication.Constants;
using SSIWalletApplication.Interface;
using SSIWalletApplication.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using Xamarin.Essentials;

namespace SSIWalletApplication.ViewModels
{
    public class RegisterViewModel : ABaseViewModel
    {
        private readonly IAgentProvider _agentContextProvider;
        private readonly IPoolConfigurator _poolConfigurator;
        private readonly IEdgeProvisioningService _provisioningService;

        public RegisterViewModel(
            IUserDialogs userDialogs,
            INavigationService navigationService,
            IAgentProvider agentProvider,
            IPoolConfigurator poolConfigurator,
            IEdgeProvisioningService provisioningService) : base(
                nameof(RegisterViewModel),
                userDialogs,
                navigationService)
        {
            _agentContextProvider = agentProvider;
            _poolConfigurator = poolConfigurator;
            _provisioningService = provisioningService;

            CreateWalletMethod();
        }

        #region Bindable Commands
        public async void CreateWalletMethod()
        {
            var dialog = UserDialogs.Instance.Loading("Creating wallet");

            try
            {
                await _poolConfigurator.ConfigurePoolsAsync();
                await _provisioningService.ProvisionAsync();
                Preferences.Set(AppConstant.LocalWalletProvisioned, true);

                await NavigationService.NavigateToAsync<SSIMasterDetailPageViewModel>();
            }
            catch (Exception e)
            {
                UserDialogs.Instance.Alert($"Failed to create wallet: {e.Message}");
                Debug.WriteLine(e);
            }
            finally
            {
                dialog?.Hide();
                dialog?.Dispose();
            }
        }
        #endregion
    }
}
