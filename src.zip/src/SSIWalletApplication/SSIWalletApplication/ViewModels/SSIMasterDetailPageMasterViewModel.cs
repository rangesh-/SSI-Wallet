﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using Xamarin.Forms;
using ReactiveUI;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using System.Threading.Tasks;
using SSIWalletApplication.ViewModels;
using Acr.UserDialogs;
using SSIWalletApplication.Interface;

namespace SSIWalletApplication.ViewModels
{
    public class SSIMasterDetailPageMasterViewModel : ABaseViewModel
    {
        public ObservableCollection<PageTypeGroup> Groups { get; set; }
        public SSIMasterDetailPageMasterViewModel(IUserDialogs userDialogs,
                                    INavigationService navigationService) :
                                    base("Connections", userDialogs, navigationService)
        {
            Groups = new ObservableCollection<PageTypeGroup>
                {
                    new PageTypeGroup("Security","")
                    {
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Create/ExportBackup" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Remover Account" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Change PIN" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Use Biometrics" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Use Mediator Images" }
                    },
                    new PageTypeGroup("Options","")
                    {
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Change Ledger" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Change Language" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Renew Push" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Gateways" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Show Mediator Connection" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Force AutoFocus" }
                    },
                    new PageTypeGroup("About Us","")
                    {
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Legal Notice" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Privacy Policy" },
                        new MasterDetailPage_SSIMasterMenuItem { Title = "Licenses" }
                    }
                };
        }

        //public async Task SelectConnection(ConnectionViewModel connection) => await NavigationService.NavigateToAsync(connection);

        //#region Commands
        //public ICommand SelectConnectionCommand => new Command<ConnectionViewModel>(async (connection) =>
        //{
        //    if (connection != null)
        //        await SelectConnection(connection);
        //});

        //#endregion
    }

    public class PageTypeGroup : List<MasterDetailPage_SSIMasterMenuItem>
    {
        public string GroupName { get; set; }
        public string Title { get; set; }
        public PageTypeGroup(string groupName, string title)
        {
            GroupName = groupName;
            Title = title;
        }
    }

    public class MasterDetailPage_SSIMasterMenuItem : ReactiveObject
    {
        public MasterDetailPage_SSIMasterMenuItem()
        {
            TargetType = typeof(MasterDetailPage_SSIMasterMenuItem);
        }

        public int Id { get; set; }
        public string Title { get; set; }
        public string GroupName { get; set; }
        public Type TargetType { get; set; }

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set => this.RaiseAndSetIfChanged(ref _isSelected, value);
        }

        private Color _selectedItemColor;
        public Color SelectedItemColor
        {
            get => _selectedItemColor;
            set => this.RaiseAndSetIfChanged(ref _selectedItemColor, value);
        }
    }
}
