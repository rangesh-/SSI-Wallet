﻿using Acr.UserDialogs;
using Hyperledger.Aries.Agents;
using Hyperledger.Aries.Agents.Edge;
using SSIWalletApplication.Constants;
using SSIWalletApplication.Interface;
using SSIWalletApplication.Services;
using SSIWalletApplication.Views;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace SSIWalletApplication.ViewModels
{
    public class SSIMasterDetailPageViewModel : ABaseViewModel,IRootView
    {
        private readonly IAgentProvider _agentContextProvider;
        private readonly IPoolConfigurator _poolConfigurator;
        private readonly IEdgeProvisioningService _provisioningService;
        protected Application CurrentApplication => Application.Current;

        public SSIMasterDetailPageViewModel(
            IUserDialogs userDialogs,
            INavigationService navigationService,
            IAgentProvider agentProvider,
            IPoolConfigurator poolConfigurator,
            IEdgeProvisioningService provisioningService) : base(
                nameof(SSIMasterDetailPageViewModel),
                userDialogs,
                navigationService)
        {
            _agentContextProvider = agentProvider;
            _poolConfigurator = poolConfigurator;
            _provisioningService = provisioningService;


            CreateWalletMethod();

        }

        #region Bindable Commands
        public async void CreateWalletMethod()
        {
            var dialog = UserDialogs.Instance.Loading("Creating wallet");
            try
            {
                if (!Preferences.Get(AppConstant.LocalWalletProvisioned, false))
                {
                    await _poolConfigurator.ConfigurePoolsAsync();
                    await _provisioningService.ProvisionAsync();
                    Preferences.Set(AppConstant.LocalWalletProvisioned, true);
                    Preferences.Set(AppConstant.IsLocalWallet, true);
                    NavigationService.SetDetailsPage<HomePageViewModel>();
                }
                else
                {
                    var dialogs= UserDialogs.Instance.Loading("Creating wallet");
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        try
                        {
                            NavigationService.SetDetailsPage<HomePageViewModel>();
                        }
                        catch (Exception ex)
                        {

                        }
                        finally
                        {
                            dialogs?.Hide();
                            dialogs?.Dispose();
                        }
                    });
                }
            }
            catch (Exception e)
            {
                UserDialogs.Instance.Alert($"Failed to create wallet: {e.Message}");
                Debug.WriteLine(e);
            }
            finally
            {
                if (Preferences.Get(AppConstant.IsLocalWallet, true))
                {
                    dialog?.Hide();
                    dialog?.Dispose();
                    Preferences.Set(AppConstant.IsLocalWallet, false);
                }
            }
        }
        #endregion
    }
}