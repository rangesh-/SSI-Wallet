﻿using Acr.UserDialogs;
using Autofac;
using Hyperledger.Aries.Agents;
using Hyperledger.Aries.Configuration;
using Hyperledger.Aries.Contracts;
using Hyperledger.Aries.Features.DidExchange;
using ReactiveUI;
using SSIWalletApplication.Constants;
using SSIWalletApplication.Extensions;
using SSIWalletApplication.Interface;
using SSIWalletApplication.Utilities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;


namespace SSIWalletApplication.ViewModels
{
    public class ScanViewModel : ABaseViewModel
    {
        private readonly IProvisioningService _provisioningService;
        private readonly IConnectionService _connectionService;
        private readonly IMessageService _messageService;
        private readonly IAgentProvider _contextProvider;
        private readonly IEventAggregator _eventAggregator;

        public bool dialog = false;

        public ScanViewModel(IUserDialogs userDialogs,
                                     INavigationService navigationService,
                                     IProvisioningService provisioningService,
                                     IConnectionService connectionService,
                                     IMessageService messageService,
                                     IAgentProvider contextProvider,
                                     IEventAggregator eventAggregator
                                     )
                                     : base("Accept Invitiation", userDialogs, navigationService)
        {
            _provisioningService = provisioningService;
            _connectionService = connectionService;
            _contextProvider = contextProvider;
            _messageService = messageService;
            _contextProvider = contextProvider;
            _eventAggregator = eventAggregator;
        }

        private async void Scanner_OnScanResult(ZXing.Result result)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                var response = result;
                if (!dialog)
                {
                    try
                    {
                        dialog = true;
                        if (await Application.Current.MainPage.DisplayAlert(result.Text, "wants to connect with you", "Connect", "Deny"))
                        {
                            if (response == null) return;
                            ConnectionInvitationMessage invitation;
                            try
                            {
                                invitation = await MessageDecoder.ParseMessageAsync(result.Text) as ConnectionInvitationMessage
                                    ?? throw new Exception("Unknown message type");
                            }
                            catch (Exception)
                            {
                                DialogService.Alert("Invalid invitation!");
                                return;
                            }
                            AcceptInviteMethod(invitation, result.Text);
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
                
            });
        }

        private async void AcceptInviteMethod(ConnectionInvitationMessage _invite,string text)
        {
            var loadingDialog = DialogService.Loading("Processing");
            var context = await _contextProvider.GetContextAsync();
            Device.BeginInvokeOnMainThread(async () =>
            {
                try
                {
                    var (msg, rec) = await _connectionService.CreateRequestAsync(context, _invite);
                    msg.Label = "SSI";

                    await _messageService.SendAsync(context.Wallet, msg, rec);

                    _eventAggregator.Publish(new ApplicationEvent() { Type = ApplicationEventType.ConnectionsUpdated });
                    Preferences.Set(AppConstant.ScanValue, result.Text);
                    NavigationService.CreateAndBindView<ConnectionsViewModel>();
                    Preferences.Set(AppConstant.ScanValue, null);
                }
                catch (Exception ex)
                {

                }

                finally
                {
                    loadingDialog.Hide();
                    //await NavigationService.PopModalAsync();
                }
            });
        }

        private ZXing.Result result;
        public ZXing.Result Result
        {
            get => result;
            set => this.RaiseAndSetIfChanged(ref result, value);
        }

        private bool _isVisiblity;
        public bool Visibility
        {
            get => _isVisiblity;
            set => this.RaiseAndSetIfChanged(ref _isVisiblity, value);
        }

        private bool isAnalyzing = true;
        public bool IsAnalyzing
        {
            get => isAnalyzing;
            set => this.RaiseAndSetIfChanged(ref isAnalyzing, value);
        }

        private bool isScanning = true;
        public bool IsScanning
        {
            get => isScanning;
            set => this.RaiseAndSetIfChanged(ref isScanning, value);
        }

        #region Bindable Command
        public ICommand ScanCommand => new Command<ZXing.Result>(async (Result) =>
        {
            if (Result != null)
                Scanner_OnScanResult(Result);
        });

        #endregion
    }
}
